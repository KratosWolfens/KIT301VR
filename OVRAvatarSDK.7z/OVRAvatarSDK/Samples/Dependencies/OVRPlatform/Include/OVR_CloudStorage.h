#pragma once

typedef const char * ovrCloudStorageVersionHandle;
